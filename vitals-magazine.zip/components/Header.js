import Link from "next/link";

export default function Header() {
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto flex items-center justify-between p-4">
        <Link href="/">
          <a className="text-2xl font-bold">Vitals Magazine</a>
        </Link>
        <nav className="space-x-6">
          <Link href="/"><a className="hover:underline">Home</a></Link>
          <Link href="/about"><a className="hover:underline">About</a></Link>
          <Link href="/issues"><a className="hover:underline">Issues</a></Link>
          <Link href="/contact"><a className="hover:underline">Contact</a></Link>
        </nav>
      </div>
    </header>
  );
}
