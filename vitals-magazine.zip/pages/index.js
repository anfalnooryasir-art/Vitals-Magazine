import Header from "../components/Header";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <section className="text-center">
          <h1 className="text-4xl font-bold mb-4">Welcome to Vitals Magazine</h1>
          <p className="mb-6">
            Your monthly dose of culture, tradition, and stories — all in one place.
          </p>
          <Link href="/issues">
            <a className="bg-accent text-white px-6 py-3 rounded hover:bg-yellow-500 transition">
              Explore Issues
            </a>
          </Link>
        </section>
      </main>
    </>
  );
}
