import Header from "../components/Header";

export default function About() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">About Vitals Magazine</h1>
        <p>
          Vitals Magazine is a monthly publication dedicated to sharing rich cultural
          stories, music, and traditions from across the region.
        </p>
      </main>
    </>
  );
}
