import Header from "../components/Header";

export default function Contact() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Contact Us</h1>
        <p>Email: <a href="mailto:contact@vitalsmagazine.com" className="text-primary underline">contact@vitalsmagazine.com</a></p>
      </main>
    </>
  );
}
